<?php

echo "Hello! This message comes from message.php.<br>";

?>
