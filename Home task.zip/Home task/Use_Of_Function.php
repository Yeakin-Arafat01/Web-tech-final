<?php


// 1. STRING FUNCTIONS


$text = "Hello World PHP";

// strlen() - counts the number of characters
echo "strlen(): " . strlen($text) . "<br>";

// str_word_count() - counts the number of words
echo "str_word_count(): " . str_word_count($text) . "<br>";

// str_contains() - checks whether a word/text exists
echo "str_contains(): ";
if (str_contains($text, "World")) {
    echo "World is found";
} else {
    echo "World is not found";
}
echo "<br>";

// strpos() - finds the position of a word/text
echo "strpos(): " . strpos($text, "World") . "<br>";

// strtoupper() - converts text to uppercase
echo "strtoupper(): " . strtoupper($text) . "<br>";

// strtolower() - converts text to lowercase
echo "strtolower(): " . strtolower($text) . "<br>";

// str_replace() - replaces text
$newText = str_replace("World", "PHP", $text);
echo "str_replace(): " . $newText . "<br>";

// strrev() - reverses a string
echo "strrev(): " . strrev($text) . "<br>";

// trim() - removes spaces from beginning and end
$spaceText = "   Hello PHP   ";
echo "trim(): " . trim($spaceText) . "<br>";

// explode() - converts string into an array
$fruits = "Apple,Banana,Mango";
$fruitArray = explode(",", $fruits);

echo "explode(): ";
print_r($fruitArray);
echo "<br><br>";

// implode() - converts array into a string
echo "implode(): " . implode(" - ", $fruitArray) . "<br>";

// substr() - gets part of a string
echo "substr(): " . substr($text, 0, 5) . "<br>";


// =====================================================
// 2. NUMBER / TYPE CHECKING FUNCTIONS
// =====================================================

$number1 = 10;
$number2 = 10.5;
$number3 = "100";

// is_int() - checks whether a value is an integer
echo "is_int(): ";
var_dump(is_int($number1));
echo "<br>";

// is_float() - checks whether a value is a float
echo "is_float(): ";
var_dump(is_float($number2));
echo "<br>";

// is_nan() - checks whether a value is Not a Number
$result = acos(2);

echo "is_nan(): ";
var_dump(is_nan($result));
echo "<br>";

// is_numeric() - checks whether a value is numeric
echo "is_numeric(): ";
var_dump(is_numeric($number3));
echo "<br>";

// round() - rounds a number
$decimal = 10.6;
echo "round(): " . round($decimal) . "<br>";


// =====================================================
// 3. CONSTANT
// =====================================================

// define() - creates a constant
define("COLLEGE", "AIUB");

echo "define(): " . COLLEGE . "<br>";


// =====================================================
// 4. DATE AND TIME FUNCTIONS
// =====================================================

// date_default_timezone_set() - sets the timezone
date_default_timezone_set("Asia/Dhaka");

// date_default_timezone_get() - shows current timezone
echo "Timezone: " . date_default_timezone_get() . "<br>";

// date() - displays date/time in a specific format
echo "date(): " . date("d-m-Y") . "<br>";

// time() - returns current Unix timestamp
echo "time(): " . time() . "<br>";

// strtotime() - converts a date string into timestamp
$date = strtotime("tomorrow");

echo "strtotime(): " . $date . "<br>";

// We can use date() again to make strtotime() understandable
echo "Tomorrow: " . date("d-m-Y", $date) . "<br>";


// =====================================================
// 5. INCLUDE AND REQUIRE
// =====================================================

include "message.php";

// =====================================================
// 6. JSON FUNCTIONS
// =====================================================

// array() - creates an array
$student = array(
    "name" => "Yeakin",
    "age" => 22,
    "department" => "CSE"
);

// json_encode() - converts PHP array into JSON
$jsonData = json_encode($student);

echo "json_encode(): " . $jsonData . "<br>";

// json_decode() - converts JSON back into PHP object
$phpData = json_decode($jsonData);

echo "json_decode(): " . $phpData->name . "<br>";


// =====================================================
// 7. ARRAY FUNCTIONS
// =====================================================

// array_keys() - returns all keys of an array
echo "array_keys(): ";
print_r(array_keys($student));
echo "<br>";

// array_merge() - combines two arrays
$array1 = array("Apple", "Banana");
$array2 = array("Mango", "Orange");

$mergedArray = array_merge($array1, $array2);

echo "array_merge(): ";
print_r($mergedArray);
echo "<br>";

// array_push() - adds item to the end of an array
array_push($mergedArray, "Grapes");

echo "array_push(): ";
print_r($mergedArray);
echo "<br>";

// array_reverse() - reverses an array
$reverseArray = array_reverse($mergedArray);

echo "array_reverse(): ";
print_r($reverseArray);
echo "<br>";

// sizeof() - counts array elements
echo "sizeof(): " . sizeof($mergedArray) . "<br>";

// count() - also counts array elements
echo "count(): " . count($mergedArray) . "<br>";


// sort() - sorts an array in ascending order
$numbers = array(50, 10, 40, 20, 30);

sort($numbers);

echo "sort(): ";
print_r($numbers);
echo "<br>";


// =====================================================
// END
// =====================================================

echo "<br><b>All functions have been implemented!</b>";

?>
